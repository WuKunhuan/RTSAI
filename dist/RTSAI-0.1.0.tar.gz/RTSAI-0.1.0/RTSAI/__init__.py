
import sys

PACKAGE_NAME = "RTSAI"
PACKAGE_VERSION = '0.1.0'
ROOT_PATH = sys.executable[::-1][sys.executable[::-1].index('/')+1:][::-1]
