
import os, setuptools
from RTSAI.config import PACKAGE_NAME, PACKAGE_VERSION, DATA_PATH

'''
Pre-installation of knowledge graph files
'''
preinstalled_knowledge_graphs = ["HKU_Intuitive"]
knowledge_graph_files = []
knowledge_graphs_dir = os.path.join(os.path.dirname(__file__), 'RTSAI', 'assets', 'knowledge_graphs')
for graph_name in preinstalled_knowledge_graphs:
    graph_dir = os.path.join(knowledge_graphs_dir, graph_name)
    graph_files = [
        os.path.join(graph_dir, 'named_entity.tsv'),
        os.path.join(graph_dir, 'prototype.tsv'),
        os.path.join(graph_dir, 'relationship.tsv')
    ]
    knowledge_graph_files.extend(graph_files)

setuptools.setup (
    name = PACKAGE_NAME, 
    version = PACKAGE_VERSION, 
    description = 'The recreated RTSAI package with pip install. ', 
    long_description = 'The recreated RTSAI package with pip install. ', 
    long_description_content_type = 'text/x-rst', 
    author = 'wukunhuan', 
    author_email = 'u3577163@connect.hku.hk', 
    url = 'https://github.com/WuKunhuan/RTSAI', 
    entry_points = {
        'console_scripts': [
            'RTSAI = RTSAI.main:main'
        ]
    }, 
    project_urls = {
        "Source": "https://github.com/WuKunhuan/RTSAI", 
    }, 
    python_requires=">=3.12.0", 
    install_requires = [
        "kgtk-wukunhuan", 
        "appdirs", 
        "pyautogui", 
        "pillow", 
    ], 
    data_files=[(DATA_PATH, knowledge_graph_files)]
)
